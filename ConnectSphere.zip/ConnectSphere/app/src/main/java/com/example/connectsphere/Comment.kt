package com.example.connectsphere

data class Comment(
    val commentId: String = "",    // Unique ID for the comment
    val text: String = "",         // The comment text
    val userId: String = "",       // The user who made the comment
    val timestamp: Long = 0L       // When the comment was made
)