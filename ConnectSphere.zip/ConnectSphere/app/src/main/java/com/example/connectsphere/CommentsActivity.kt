package com.example.connectsphere

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

class CommentsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var commentInput: EditText
    private lateinit var sendButton: Button
    private lateinit var commentsAdapter: CommentsAdapter
    private lateinit var postId: String
    private var commentsListener: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comments)

        recyclerView = findViewById(R.id.comments_recycler_view)
        commentInput = findViewById(R.id.comment_input)
        sendButton = findViewById(R.id.send_comment_button)

        // Get the postId from the Intent
        postId = intent.getStringExtra("POST_ID") ?: ""

        // Set up RecyclerView
        commentsAdapter = CommentsAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = commentsAdapter

        // Load comments from Firestore
        loadComments()

        // Handle send button click
        sendButton.setOnClickListener {
            val commentText = commentInput.text.toString().trim()
            if (commentText.isNotEmpty()) {
                addComment(commentText)
                commentInput.text.clear()
            }
        }
    }

    private fun loadComments() {
        if (postId.isNotEmpty()) {
            commentsListener = FirebaseUtil.firestore.collection("posts")
                .document(postId)
                .collection("comments")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener { snapshot, e ->
                    if (e != null) return@addSnapshotListener

                    val comments = snapshot?.documents?.mapNotNull { doc ->
                        doc.toObject(Comment::class.java)?.copy(commentId = doc.id)
                    } ?: emptyList()

                    commentsAdapter.updateComments(comments)

                    // Update comment count in the parent post
                    FirebaseUtil.firestore.collection("posts")
                        .document(postId)
                        .update("commentCount", comments.size)
                }
        }
    }

    private fun addComment(text: String) {
        val userId = FirebaseUtil.auth.currentUser?.uid ?: return
        val comment = hashMapOf(
            "text" to text,
            "userId" to userId,
            "timestamp" to System.currentTimeMillis()
        )

        FirebaseUtil.firestore.collection("posts")
            .document(postId)
            .collection("comments")
            .add(comment)
            .addOnSuccessListener { documentReference ->
                // Comment added, real-time listener will update the UI
            }
            .addOnFailureListener { e ->
                // Handle failure (e.g., show a Toast)
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        commentsListener?.remove() // Clean up listener
    }
}