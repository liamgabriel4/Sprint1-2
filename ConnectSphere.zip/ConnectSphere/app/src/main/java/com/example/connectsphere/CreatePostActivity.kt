package com.example.connectsphere

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CreatePostActivity : AppCompatActivity() {
    private lateinit var imagePreview: ImageView
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var selectedBitmap: Bitmap? = null
    private var cameraProvider: ProcessCameraProvider? = null

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startCamera()
        } else {
            if (!shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                Toast.makeText(this, "Camera permission denied. Please enable it in settings.", Toast.LENGTH_LONG).show()
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Camera permission denied. Please grant permission to use the camera.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val galleryPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            pickImageFromGallery()
        } else {
            if (!shouldShowRequestPermissionRationale(Manifest.permission.READ_MEDIA_IMAGES)) {
                Toast.makeText(this, "Storage permission denied. Please enable it in settings.", Toast.LENGTH_LONG).show()
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Storage permission denied. Please grant permission to access gallery.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data?.data
            if (data != null) {
                try {
                    selectedBitmap = MediaStore.Images.Media.getBitmap(contentResolver, data)
                    imagePreview.setImageBitmap(selectedBitmap)
                    imagePreview.visibility = View.VISIBLE
                    previewView.visibility = View.GONE
                    captureButton.visibility = View.GONE
                    Toast.makeText(this, "Image selected from gallery!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Failed to load image: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_post)

        val captionField = findViewById<EditText>(R.id.caption_field)
        imagePreview = findViewById(R.id.post_image_preview)
        previewView = findViewById(R.id.preview_view)
        captureButton = findViewById(R.id.capture_button)
        val cameraButton = findViewById<Button>(R.id.camera_button)
        val galleryButton = findViewById<Button>(R.id.gallery_button)
        val uploadButton = findViewById<Button>(R.id.upload_button)

        cameraExecutor = Executors.newSingleThreadExecutor()

        cameraButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        captureButton.setOnClickListener {
            takePhoto()
        }

        galleryButton.setOnClickListener {
            val permission = if (android.os.Build.VERSION.SDK_INT >= 33) {
                Manifest.permission.READ_MEDIA_IMAGES
            } else {
                Manifest.permission.READ_EXTERNAL_STORAGE
            }
            if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                pickImageFromGallery()
            } else {
                galleryPermissionLauncher.launch(permission)
            }
        }

        uploadButton.setOnClickListener {
            val caption = captionField.text.toString()
            if (caption.isNotEmpty() && selectedBitmap != null) {
                uploadPost(caption)
            } else {
                Toast.makeText(this, "Add a caption and image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startCamera() {
        previewView.visibility = View.VISIBLE
        imagePreview.visibility = View.GONE
        captureButton.visibility = View.VISIBLE

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder().build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, cameraSelector, preview, imageCapture)
                Toast.makeText(this, "Camera opened successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Camera error: ${e.message}", Toast.LENGTH_SHORT).show()
                previewView.visibility = View.GONE
                imagePreview.visibility = View.VISIBLE
                captureButton.visibility = View.GONE
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: return
        imageCapture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: androidx.camera.core.ImageProxy) {
                    selectedBitmap = image.toBitmap()
                    imagePreview.setImageBitmap(selectedBitmap)
                    imagePreview.visibility = View.VISIBLE
                    previewView.visibility = View.GONE
                    captureButton.visibility = View.GONE
                    cameraProvider?.unbindAll()
                    image.close()
                    Toast.makeText(this@CreatePostActivity, "Photo captured successfully!", Toast.LENGTH_SHORT).show()
                }

                override fun onError(exception: ImageCaptureException) {
                    Toast.makeText(this@CreatePostActivity, "Capture failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                    previewView.visibility = View.GONE
                    imagePreview.visibility = View.VISIBLE
                    captureButton.visibility = View.GONE
                    cameraProvider?.unbindAll()
                }
            }
        )
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            galleryLauncher.launch(intent)
            Toast.makeText(this, "Opening gallery...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gallery app not found: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun uploadPost(caption: String) {
        val bitmap = selectedBitmap ?: return
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val imageBytes = baos.toByteArray()
        val imageBase64 = Base64.encodeToString(imageBytes, Base64.DEFAULT)

        val userId = FirebaseUtil.auth.currentUser?.uid ?: return
        val post = hashMapOf(
            "imageBase64" to imageBase64,
            "caption" to caption,
            "userId" to userId,
            "timestamp" to System.currentTimeMillis()
        )

        FirebaseUtil.firestore.collection("posts")
            .add(post)
            .addOnSuccessListener {
                Toast.makeText(this, "Post uploaded!", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        cameraProvider?.unbindAll()
    }
}