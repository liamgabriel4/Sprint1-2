package com.example.connectsphere

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.feed_recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_nav)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_feed -> true
                R.id.nav_post -> {
                    startActivity(Intent(this, CreatePostActivity::class.java))
                    true
                }
                else -> false
            }
        }

        loadPosts(recyclerView)
    }

    private fun loadPosts(recyclerView: RecyclerView) {
        FirebaseUtil.firestore.collection("posts")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { result ->
                val posts = result.map { it.toObject(Post::class.java) }
                recyclerView.adapter = PostAdapter(posts)
            }
            .addOnFailureListener { e ->
                // Handle error if needed
            }
    }
}