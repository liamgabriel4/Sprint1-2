package com.example.connectsphere

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.firestore.ListenerRegistration

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var postAdapter: PostAdapter
    private var postListener: ListenerRegistration? = null // To manage the Firestore listener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.feed_recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        postAdapter = PostAdapter(emptyList()) // Initialize with empty list
        recyclerView.adapter = postAdapter

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_nav)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_feed -> true
                R.id.nav_post -> {
                    startActivity(Intent(this, CreatePostActivity::class.java))
                    true
                }
                else -> false
            }
        }

        loadPosts() // Load posts with real-time listener
    }

    private fun loadPosts() {
        postListener = FirebaseUtil.firestore.collection("posts")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    // Handle error if needed
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val posts = snapshot.map { it.toObject(Post::class.java) }
                    postAdapter.updatePosts(posts) // Update the adapter with new data
                }
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        postListener?.remove() // Clean up the listener to avoid memory leaks
    }
}