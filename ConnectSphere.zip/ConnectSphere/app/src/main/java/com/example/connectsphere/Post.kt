package com.example.connectsphere

data class Post(
    val imageBase64: String = "",
    val caption: String = "",
    val userId: String = "",
    val timestamp: Long = 0L,
    val postId: String = "",
    val likes: Int = 0,
    val likedBy: List<String> = emptyList(),
    val commentCount: Int = 0      // Added to track the number of comments
)