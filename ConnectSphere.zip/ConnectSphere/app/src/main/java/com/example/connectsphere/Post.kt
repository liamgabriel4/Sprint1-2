package com.example.connectsphere

data class Post(
    val imageBase64: String = "",
    val caption: String = "",
    val userId: String = "",
    val timestamp: Long = 0L
)