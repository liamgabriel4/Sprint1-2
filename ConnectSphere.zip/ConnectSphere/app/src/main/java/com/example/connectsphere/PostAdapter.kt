package com.example.connectsphere

import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter(private var posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {
    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.post_image)
        val captionText: TextView = itemView.findViewById(R.id.post_caption)
        val likeButton: ImageButton = itemView.findViewById(R.id.like_button)
        val likeCount: TextView = itemView.findViewById(R.id.like_count)
        val commentButton: ImageButton = itemView.findViewById(R.id.comment_button)
        val commentCount: TextView = itemView.findViewById(R.id.comment_count)
        val deleteButton: ImageButton = itemView.findViewById(R.id.delete_button) // Add delete button
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        val imageBytes = Base64.decode(post.imageBase64, Base64.DEFAULT)
        val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
        holder.imageView.setImageBitmap(bitmap)
        holder.captionText.text = post.caption
        holder.likeCount.text = "${post.likes} likes"
        holder.commentCount.text = "${post.commentCount} comments"

        // Check if the current user has liked the post
        val currentUserId = FirebaseUtil.auth.currentUser?.uid ?: ""
        val hasLiked = post.likedBy.contains(currentUserId)

        // Show delete button only if the current user is the post's creator
        holder.deleteButton.visibility = if (post.userId == currentUserId) View.VISIBLE else View.GONE

        // Set the like button icon based on whether the user has liked the post
        holder.likeButton.setImageResource(
            if (hasLiked) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off
        )

        holder.likeButton.setOnClickListener {
            if (post.postId.isNotEmpty()) {
                if (!hasLiked) {
                    val newLikedBy = post.likedBy.toMutableList().apply { add(currentUserId) }
                    val updates = hashMapOf<String, Any>(
                        "likes" to post.likes + 1,
                        "likedBy" to newLikedBy
                    )
                    FirebaseUtil.firestore.collection("posts")
                        .document(post.postId)
                        .update(updates)
                        .addOnSuccessListener {
                            // Firestore update successful, real-time listener in MainActivity will refresh the UI
                        }
                        .addOnFailureListener { e ->
                            holder.likeCount.text = "${post.likes} likes"
                            holder.likeButton.setImageResource(android.R.drawable.btn_star_big_off)
                        }
                } else {
                    val newLikedBy = post.likedBy.toMutableList().apply { remove(currentUserId) }
                    val updates = hashMapOf<String, Any>(
                        "likes" to (post.likes - 1).coerceAtLeast(0),
                        "likedBy" to newLikedBy
                    )
                    FirebaseUtil.firestore.collection("posts")
                        .document(post.postId)
                        .update(updates)
                        .addOnSuccessListener {
                            // Firestore update successful, real-time listener in MainActivity will refresh the UI
                        }
                        .addOnFailureListener { e ->
                            holder.likeCount.text = "${post.likes} likes"
                            holder.likeButton.setImageResource(android.R.drawable.btn_star_big_on)
                        }
                }
            } else {
                holder.likeCount.text = "${post.likes} likes"
            }
        }

        // Handle comment button click
        holder.commentButton.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, CommentsActivity::class.java).apply {
                putExtra("POST_ID", post.postId)
            }
            context.startActivity(intent)
        }

        // Handle delete button click
        holder.deleteButton.setOnClickListener {
            if (post.postId.isNotEmpty()) {
                // Delete the post
                FirebaseUtil.firestore.collection("posts")
                    .document(post.postId)
                    .delete()
                    .addOnSuccessListener {
                        // Post deleted, real-time listener in MainActivity will refresh the UI
                        // Now delete the comments subcollection
                        FirebaseUtil.firestore.collection("posts")
                            .document(post.postId)
                            .collection("comments")
                            .get()
                            .addOnSuccessListener { snapshot ->
                                for (document in snapshot.documents) {
                                    document.reference.delete()
                                }
                            }
                    }
                    .addOnFailureListener { e ->
                        // Handle failure (e.g., show a Toast)
                    }
            }
        }
    }

    override fun getItemCount(): Int = posts.size

    fun updatePosts(newPosts: List<Post>) {
        posts = newPosts
        notifyDataSetChanged()
    }
}